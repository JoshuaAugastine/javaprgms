package Assesment3;

import java.util.Scanner;

public class Increasing {

	public static void main(String[] args) {
		 int n,count=0,count2=0;
	       Scanner x = new Scanner(System.in);
	       System.out.println("enter the no. of elements you want in array :");
	       n = x.nextInt();
	       int arr[]= new int [n];
	       System.out.println("enter the no. of elements you want in array :");
	       for(int i=0; i<n; i++) {
	       arr[i] = x.nextInt();
	       }
	       
	       for(int i=0; i<n; i++) {
	    	  if(arr[i-1]>=arr[i]) {
	    		  count++;
	    		  
	    	(count>1)
	    		  return false;
	  	  
	    	(count==0)
	    		  return true;
	    	
	    	    System.out.println("strictly increasing");
	       }      	  
	       else {
	    	  System.out.println("strictly not increasing");
	      
}
	    	   }
	       
	}}

