package Assesment1;

public class Pokemon {

	public static void main(String[] args) {
		
		int a=4,b=3;
		if(a>b) {
			System.out.println("1");
		}
		else {
			System.out.print("0");
		}

	}

}
