package Assesment1;

public class Helpsharlock {

	public static void main(String[] args) {
		   int n=3,m=4;
					if(n%m==0) {
						System.out.println(1);
					}
					else {
						System.out.println(0);
					}
				}
}	
		