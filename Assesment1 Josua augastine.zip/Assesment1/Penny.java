package Assesment1;

public class Penny {

	public static void main(String[] args) {

				int n=8; 
				int m=5;
				
				if(m/n>0) {
					System.out.println(m/n);
				}
				else
					System.out.println(-1);
				
	}
	}

